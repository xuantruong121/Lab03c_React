import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import axios from 'axios';
import { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

const colorMap: Record<string, string> = {
  Đỏ: 'red',
  Xanh: '#234896',
  Đen: 'black',
  Bạc: '#C5F1FB',
};

function HomeScreen({ navigation, route }: { navigation: any; route: any }) {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState<any>(null);

  useEffect(() => {
    axios
      .get('https://683097576205ab0d6c39b6ae.mockapi.io/products')
      .then((res) => {
        setProducts(res.data);

        if (route.params?.selectedVariant) {
          setSelectedVariant(route.params.selectedVariant);
        } else {
          setSelectedVariant(res.data[0]);
        }

        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [route.params?.selectedVariant]); 

  if (loading || !selectedVariant) {
    return <ActivityIndicator size="large" color="blue" style={{ flex: 1 }} />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'white', padding: 10 }}>
      <Image
        source={{ uri: selectedVariant.image }}
        style={styles.productImg}
      />
      <Text style={styles.prdText}>{selectedVariant.name}</Text>

      <View style={styles.rating}>
        <View style={styles.ratingStar}>
          <Image source={require('../assets/bai1/star.png')} />
          <Image source={require('../assets/bai1/star.png')} />
          <Image source={require('../assets/bai1/star.png')} />
          <Image source={require('../assets/bai1/star.png')} />
          <Image source={require('../assets/bai1/star.png')} />
        </View>
        <Text style={styles.numRating}>(Xem 828 đánh giá)</Text>
      </View>

      <View style={styles.price_discount}>
        <Text style={styles.price}>{selectedVariant.price} đ</Text>
        <Text style={styles.discount}>1.990.000 đ</Text>
      </View>

      <View style={styles.repay}>
        <Text style={styles.repayText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>
        <Image
          source={require('../assets/bai1/Group 1.png')}
          style={styles.repayIcon}
        />
      </View>

      <TouchableOpacity
        style={styles.colorpickButton}
        onPress={() =>
          navigation.navigate('Details', {
            currentVariant: selectedVariant,
            allProducts: products,
          })
        }>
        <Text style={styles.clpickerText}>
          {products.length} MÀU - CHỌN MÀU
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buyButton}>
        <Text style={styles.buyText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

function DetailsScreen({ route, navigation }: any) {
  const { currentVariant, allProducts } = route.params;
  const [selectedVariant, setSelectedVariant] = useState(currentVariant);

  useEffect(() => {
    console.log('Variant hiện tại trong Details:', selectedVariant);
  }, [selectedVariant]);

  return (
    <View style={{ flex: 1, backgroundColor: 'white', padding: 10 }}>
      <View style={{ flexDirection: 'row', marginBottom: 15 }}>
        <Image
          source={{ uri: selectedVariant.image }}
          style={{ width: 170, height: 210, marginRight: 10 }}
        />
        <View style={{ flex: 1, justifyContent: 'center' }}>
          <Text style={{ fontWeight: 'bold' }}>{selectedVariant.name}</Text>
          <Text>Màu: {selectedVariant.color}</Text>
          <Text>
            Cung cấp bởi{' '}
            <Text style={{ fontWeight: 'bold' }}>
              {selectedVariant.supplier}
            </Text>
          </Text>
          <Text style={{ fontWeight: 'bold', fontSize: 16 }}>
            {selectedVariant.price} đ
          </Text>
        </View>
      </View>

      <View
        style={{
          flex: 1,
          marginVertical: 10,
          backgroundColor: '#e0e0e0',
          width: '100%',
          alignItems: 'center',
          paddingVertical: 15,
          borderRadius: 10,
        }}>
        <Text style={{ marginVertical: 10, fontSize: 18, fontWeight: 'bold' }}>
          Chọn một màu bên dưới:
        </Text>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {allProducts.map((prod: any) => (
            <TouchableOpacity
              key={prod.id}
              onPress={() => setSelectedVariant(prod)}>
              <View
                style={{
                  width: 60,
                  height: 60,
                  backgroundColor: colorMap[prod.color] || '#ccc',
                  margin: 5,
                  borderWidth: selectedVariant.id === prod.id ? 2 : 0,
                  borderColor: 'blue',
                }}
              />
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <TouchableOpacity
        onPress={() => {
          navigation.navigate('Home', { selectedVariant });
        }}
        style={styles.doneButton}>
        <Text style={styles.doneText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
}

export default function Bai1() {
  return (
    <View style={styles.container}>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Details" component={DetailsScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  ratingStar: {
    flexDirection: 'row',
  },
  numRating: {
    marginLeft: 15,
  },
  price_discount: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  price: {
    fontWeight: 'bold',
    fontSize: 17,
  },
  discount: {
    marginLeft: 15,
    color: 'grey',
    textDecorationLine: 'line-through',
  },
  repay: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    marginTop: 8,
  },
  repayIcon: {
    marginLeft: 10,
  },
  repayText: {
    color: 'red',
    fontSize: 12,
    fontWeight: 'bold',
  },
  prdText: {
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 5,
  },
  productImg: {
    height: 320,
    width: 260,
    alignSelf: 'center',
  },
  colorpickButton: {
    borderWidth: 1,
    borderRadius: 10,
    alignItems: 'center',
  },
  clpickerText: {
    padding: 5,
  },
  buyButton: {
    borderWidth: 1,
    borderRadius: 10,
    alignItems: 'center',
    backgroundColor: 'red',
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  buyText: {
    padding: 8,
    color: 'white',
    fontWeight: 'bold',
  },
  doneButton: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#1952E294',
    borderWidth: 1,
    borderRadius: 10,
    alignItems: 'center',
    margin: 10,
  },
  doneText: {
    padding: 8,
    color: 'white',
    fontWeight: 'bold',
  },
});
