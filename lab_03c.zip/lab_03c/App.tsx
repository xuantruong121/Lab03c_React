import Bai1 from './components/bai1'
import Bai2 from './components/bai2'
import Bai3 from './components/bai3'
import Bai4 from './components/bai4'
import Bai5 from './components/bai5'

export default function App() {
  return(
    // <Bai1></Bai1>
    // <Bai2></Bai2>
    // <Bai3></Bai3>
    // <Bai4></Bai4>
    <Bai5></Bai5>
  )
}