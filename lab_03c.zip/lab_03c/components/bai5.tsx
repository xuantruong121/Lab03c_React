import * as React from "react";
import { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Switch,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";

type DrawerParamList = {
  Home: undefined;
  Profile: undefined;
  Settings: undefined;
};

const Drawer = createDrawerNavigator<DrawerParamList>();

function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>🏠 Đây là Home Screen</Text>
    </View>
  );
}

function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👤 Thông tin User</Text>
      <Text style={styles.text}>Tên: Nguyễn Văn A</Text>
      <Text style={styles.text}>Email: nguyenvana@example.com</Text>
    </View>
  );
}

function SettingsScreen() {
  const [isEnabled, setIsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>⚙️ Cài đặt</Text>

      <View style={styles.row}>
        <Text style={styles.text}>Thông báo</Text>
        <Switch
          value={isEnabled}
          onValueChange={setIsEnabled}
        />
      </View>

      <View style={styles.row}>
        <Text style={styles.text}>Dark Mode</Text>
        <Switch
          value={darkMode}
          onValueChange={setDarkMode}
        />
      </View>
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: true,
        }}
      >
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Profile" component={ProfileScreen} />
        <Drawer.Screen name="Settings" component={SettingsScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
  },
  text: {
    fontSize: 18,
    marginBottom: 10,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "80%",
    marginVertical: 10,
    alignItems: "center",
  },
});
