import * as React from "react";
import { useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

type RootStackParamList = {
  Home: undefined;
  ProductDetails: { id: number };
};

type HomeTabParamList = {
  Products: undefined;
  Favorites: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<HomeTabParamList>();

const PRODUCTS = [
  { id: 1, name: "iPhone 15 Pro", price: 1200 },
  { id: 2, name: "Samsung Galaxy S24", price: 1100 },
  { id: 3, name: "Xiaomi 14 Ultra", price: 900 },
  { id: 4, name: "Xiaomi 17 Ultra", price: 3000 },
];

function ProductsScreen({ navigation }: any) {
  const [favorites, setFavorites] = useState<number[]>([]);

  const toggleFavorite = (id: number) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={PRODUCTS}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() =>
              navigation.navigate("ProductDetails", { id: item.id })
            }
            onLongPress={() => toggleFavorite(item.id)}
          >
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.price}>${item.price}</Text>
            {favorites.includes(item.id) && (
              <Text style={{ color: "tomato" }}>❤️ Yêu thích</Text>
            )}
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function FavoritesScreen() {
  const favorites = PRODUCTS.filter((p) => p.id % 2 === 0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Favorites</Text>
      {favorites.map((item) => (
        <Text key={item.id} style={styles.item}>
          {item.name} - ${item.price}
        </Text>
      ))}
    </View>
  );
}

function ProductDetailsScreen({ route }: any) {
  const { id } = route.params;
  const product = PRODUCTS.find((p) => p.id === id);

  if (!product) {
    return (
      <View style={styles.container}>
        <Text>Sản phẩm không tồn tại</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Chi tiết sản phẩm</Text>
      <Text style={styles.name}>{product.name}</Text>
      <Text style={styles.price}>Giá: ${product.price}</Text>
    </View>
  );
}

function HomeTabs() {
  return (
    <Tab.Navigator screenOptions={{headerShown:false}}>
      <Tab.Screen name="Products" component={ProductsScreen} />
      <Tab.Screen name="Favorites" component={FavoritesScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={HomeTabs}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ProductDetails"
          component={ProductDetailsScreen}
          options={{ title: "Chi tiết sản phẩm" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center" },
  item: {
    padding: 16,
    borderBottomWidth: 1,
    borderColor: "#ccc",
    width: 300,
    alignItems: "center",
  },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 10 },
  name: { fontSize: 18, fontWeight: "500" },
  price: { fontSize: 16, color: "gray" },
});
